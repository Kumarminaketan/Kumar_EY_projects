package Pages;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Actiondriver.Action;
import util.Read_excel;
import util.Readconfig;
import util.TestBase;

public class Vendor_Home_page extends TestBase {
	Action action = new Action();
	Readconfig read = new Readconfig();
	Read_excel r = new Read_excel();

	// Initializing the Page Objects:
	public Vendor_Home_page() {
		PageFactory.initElements(getdriver(), this);
	}

	@FindBy(xpath = "(//div[contains(@class,'ui-dropdown-trigger')]/span)[1]")
	WebElement Click_Vendor_dropdown;

	@FindBy(xpath = "//li[@role='option']/span")
	List<WebElement> Vendor_value;

	@FindBy(xpath = "(//div[contains(@class,'ui-dropdown-trigger')]/span)[2]")
	WebElement Click_Month_dropdown;

	@FindBy(xpath = "//li[@role='option']/span")
	List<WebElement> Month_value;

	@FindBy(xpath = "(//tr[@class='ng-star-inserted'])[2] //th")
	List<WebElement> header;

	@FindBy(xpath = "//tbody/tr //td[1]")
	List<WebElement> Plant_value;

	@FindBy(xpath = "//tbody/tr //td[2]")
	List<WebElement> Parts_value;

	@FindBy(xpath = "//tbody/tr //td[3]")
	List<WebElement> Part_description_value;

	@FindBy(xpath = "//tr[@class='ng-star-inserted'] //td[@class='text-center']/div[1]")
	List<WebElement> inward_consumption;

	@FindBy(xpath = "//tr[@class='ng-star-inserted'] //td[2]")
	List<WebElement> materialcode;

	@FindBy(xpath = "//tr[@class='ng-star-inserted'] //td[@class='text-center ng-star-inserted']/div[1]")
	List<WebElement> inward_consumption_Sum;

	@FindBy(xpath = "//div[@class='date-style']")
	List<WebElement> Month_Days;

	@FindBy(xpath = "//tr[@class='ng-star-inserted'] //td[@class='text-center']/div[2]")
	List<WebElement> Total_Commiment;
	
	
	
	public void select_vendor() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("Info: click on the vendor dropdown button");
		action.explicitWait(getdriver(), Click_Vendor_dropdown, 5);
		action.checkEnable(getdriver(), Click_Vendor_dropdown);
		action.click(getdriver(), Click_Vendor_dropdown);
		for (WebElement e : Vendor_value) {
			// System.out.println(e.getText());
			if (e.getText().contentEquals(read.Vendorname())) {
				e.click();
				break;
			}
		}

		System.out.println("Info: Entered vendor dropdownvalue successfully");
		Thread.sleep(2000);
	}

	public void select_month() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("Info: click on the Month dropdown button");
		action.explicitWait(getdriver(), Click_Month_dropdown, 5);
		action.checkEnable(getdriver(), Click_Month_dropdown);
		action.click(getdriver(), Click_Month_dropdown);
		int count=0;
		for (WebElement e : Month_value) {
			System.out.println(e.getText());
			if (e.getText().contentEquals(read.Monthvalue())) {
				e.click();
				count=count+1;
				break;
			}
			
		}
		if(count!=1)
		{
			System.out.println("Error: Month value is not matching");
		
		Assert.assertEquals(count==1, true);
		}

	}

	public void plant_value() throws InterruptedException {
		System.out.println("Info: Verify the plant Vlue");
		String s = action.getText(getdriver(), header.get(0));
		// System.out.println(s);
		List<String> plant_value = read.CV_Plant();

		for (WebElement e : Plant_value) {
			int count = 0;
			// System.out.println(e.getText());
			boolean a = e.getText().equalsIgnoreCase("");
			if (e.getText().equalsIgnoreCase("")) {
				System.out.println("Error: Plant code is displaying blank");
			}
			Assert.assertEquals(a, false);
			for (int i = 0; i < plant_value.size(); i++) {

				if (e.getText().contains(plant_value.get(i))) {
					count = count + 1;

				}
			}
			if (count != 1) {
				System.out.println("Error: The plant code is not correct");
			}
			Assert.assertEquals(count == 1, true);
		}

	}

	public void part_value() throws InterruptedException, IOException {
		System.out.println("Info: Get the part code value");
		System.out.println("Info: Header value is : " + action.getText(getdriver(), header.get(1)));
		List<String> screen_material = new ArrayList<String>();
		String s = "";
		for (WebElement e : Parts_value) {
			screen_material.add(e.getText());
		}

		List<String> sheet_vendor = r.read_excel_Uniquedata(0, 4);
		List<String> sheet_material_All = r.read_excel_Uniquedata(0, 3);
		List<String> sheet_material_notfound = new ArrayList<String>();
		Set<String> found_material = new HashSet<String>();
		int count = 0;
		for (int i = 0; i <= sheet_vendor.size() - 1; i++) {

			if (sheet_vendor.get(i).equalsIgnoreCase(read.vendorcode())) {
				s = sheet_material_All.get(i);

				if (screen_material.contains(s)) {
					found_material.add(s);
					// System.out.println("Material displayed in the screen "+s);
				} else {
					count = count + 1;
					sheet_material_notfound.add(sheet_material_All.get(i));
				}
			}

		}
		// System.out.println(found_material);
		if (count > 0) {
			System.out.println("Error: " + count
					+ " mateial are not displayed in the screen check if in the data sheet you have data for only valid ode code 1001,1500,2001,3001,3100       "
					+ sheet_material_notfound);
			boolean a = sheet_material_notfound.size() == 0;
			Assert.assertEquals(a, true, "Error: Some material are not available in the screen please check the data");
		}

	}

	public void partdescription_value() throws InterruptedException {
		System.out.println("Info: Get the part description value");
		System.out.println("Info: Headers value is : " + action.getText(getdriver(), header.get(2)));
		for (WebElement e : Part_description_value) {
			// System.out.println(e.getText());
			boolean a = e.getText().equalsIgnoreCase("");
			if (e.getText().equalsIgnoreCase("")) {
				System.out.println("Error: Blank value displaye in the screen");

			}
			Assert.assertEquals(a, false);

		}
	}

	public void inword_consumption() throws IOException {

		HashMap<String, Integer> screen_value2 = new HashMap<String, Integer>();
		HashMap<String, Integer> screen_Inwardconsumption_sum = new HashMap<String, Integer>();
		int count = 0;

		for (int i = 0; i < materialcode.size(); i++) {
			screen_value2.put(action.getText(getdriver(), materialcode.get(i)),
					Integer.parseInt(action.getText(getdriver(), inward_consumption.get(i))));
			for (int j = 0; j < Month_Days.size(); j++) {
				if (inward_consumption_Sum.get(count + j).getText() != null) {
					if (screen_Inwardconsumption_sum.containsKey(materialcode.get(i).getText())) {
						screen_Inwardconsumption_sum.put(action.getText(getdriver(), materialcode.get(i)),
								screen_Inwardconsumption_sum.get(materialcode.get(i).getText()) + Integer
										.parseInt(action.getText(getdriver(), inward_consumption_Sum.get(count + j))));
					} else {
						screen_Inwardconsumption_sum.put(action.getText(getdriver(), materialcode.get(i)),
								Integer.parseInt(action.getText(getdriver(), inward_consumption_Sum.get(count + j))));
					}
				}
			}
			count = count + Month_Days.size() + 4;
		}
		action.validate_map_data(getdriver(), screen_value2, screen_Inwardconsumption_sum,
				"Day level inward consumption matching with material level inwardconsumption",
				"Day level Inword consumption is not matching with material level Inword consumption");
		List<String> sheet_vendor = r.read_excel_Uniquedata(0, 4);
		List<String> sheet_material_All = r.read_excel_Uniquedata(0, 3);
		List<String> sheet_quantity = r.read_excel_Uniquedata(0, 6);
		HashMap<String, Integer> sheetvalue2 = new HashMap<String, Integer>();
		for (int i = 0; i <= sheet_material_All.size() - 1; i++) {
			if (sheet_vendor.get(i).equalsIgnoreCase(read.vendorcode())) {

				if (sheetvalue2.containsKey(sheet_material_All.get(i))) {
					sheetvalue2.put(sheet_material_All.get(i),
							sheetvalue2.get(sheet_material_All.get(i)) + (Integer.parseInt(sheet_quantity.get(i))));
				} else {
					sheetvalue2.put(sheet_material_All.get(i), Integer.parseInt(sheet_quantity.get(i)));
				}
			}
		}
		action.validate_map_data(getdriver(), screen_value2, sheetvalue2,
				"Screen total-inward consumption wrt material is exactly matching with Sheet total-inward consumption wrt material",
				"Screen total-inward consumption wrt material is NOT matching with Sheet total-inward consumption wrt material");

	}
}
