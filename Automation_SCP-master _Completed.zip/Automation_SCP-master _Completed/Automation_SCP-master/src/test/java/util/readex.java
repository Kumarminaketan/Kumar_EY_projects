package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readex {

	public static void main(String[] args) throws IOException {
		//File l=new File("C:\\\\Users\\\\FQ495BQ\\\\OneDrive - EY\\\\Documents\\\\Selenium\\\\Projects EY\\\\Automation_SCP-master _Completed\\\\Automation_SCP-master\\\\configuration\\\\mrp 23.xlsx");
		FileInputStream fil = new FileInputStream(new File("C:\\\\Users\\\\FQ495BQ\\\\OneDrive - EY\\\\Documents\\\\Selenium\\\\Projects EY\\\\Automation_SCP-master _Completed\\\\Automation_SCP-master\\\\configuration\\\\mrp 23.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fil);
		XSSFSheet sh = wb.getSheetAt(0);
		String value=sh.getRow(0).getCell(1).getStringCellValue();
		System.out.println(value);

	}

}
